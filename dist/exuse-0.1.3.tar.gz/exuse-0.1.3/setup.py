#!/usr/bin/env python
# coding: utf-8
from setuptools import setup
from setuptools import find_packages

setup(
    name='exuse',
    version='0.1.3',
    author='barwe',
    author_email='barwechin@163.com',
    url='',
    description='简单的使用简单的工具',
    packages=find_packages(),
    install_requires=[],
)